/* XXX NetBSD dependent strace print functions */
