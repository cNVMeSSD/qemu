/* XXX OpenBSD dependent strace print functions */
