/*
 * HVF stubs for QEMU
 *
 *  Copyright (c) Linaro
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include "qemu/osdep.h"
#include "system/hvf.h"

bool hvf_allowed;
