/*
 * Dummy cpu thread code
 *
 * Copyright IBM, Corp. 2011
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef ACCEL_DUMMY_CPUS_H
#define ACCEL_DUMMY_CPUS_H

void dummy_start_vcpu_thread(CPUState *cpu);

#endif
